import { Component, OnInit, Inject, ElementRef, ViewChild } from '@angular/core';
import { RouterExtensions } from "nativescript-angular/router";
import { Router } from "@angular/router";
import { AuthenticationService } from './../../services/common/authentication.service';
import * as ApplicationSettings from "application-settings";
import { Page, EventData } from "ui/page";
import * as Toast from "nativescript-toast";
import * as EmailValidator from "email-validator";
import { TextField } from 'ui/text-field';
import { SecureStorage } from "nativescript-secure-storage";
import { MessageService } from './../../services/common/message.service';
import * as application from "application";
import { AndroidApplication, AndroidActivityBackPressedEventData } from "application";
import { isAndroid } from "platform";
// import { Button } from "ui/button";
import { Observable } from "rxjs/Rx"
// import buttonModule = require("ui/button");
import { login } from 'tns-core-modules/ui/dialogs/dialogs';
import { ValidationConfig } from './../../config/validation-config.constants';

// var testButton = new buttonModule.Button();
@Component({
	moduleId: module.id,
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.css'],
	providers: [MessageService]
})
export class LoginComponent implements OnInit {
	@ViewChild("firstTextField") userTextField: ElementRef;
	@ViewChild("secondTextField") secondTextField: ElementRef;
	public errorMessage: any;
	public loginInfo = {
		email: "",
		password: ""
	};
	public isSecure: boolean = true;
	public isLoading = false;
	public isTap: boolean = true;
	public passwordPattern=ValidationConfig.PASSWORD_PATTERN;
	public emailpattern=ValidationConfig.GOOGLE_PATTERN;
	public isEnabled: boolean = true;
	public isVerified:boolean=true;

	public constructor(private page: Page,
		private router: Router,
		private routerExten: RouterExtensions,
		private loginService: AuthenticationService,
		private messageService: MessageService) {
		this.page.actionBarHidden = true;

	}

	public ngOnInit() {
		this.page.actionBarHidden = true;
		this.userTextField.nativeElement.dismissSoftInput();
		this.secondTextField.nativeElement.dismissSoftInput();
	}
	count = 1;
	onLogin(userInfo: any) {
		this.isEnabled = false;
		this.secondTextField.nativeElement.dismissSoftInput();
		this.errorMessage = '';
		let authObj = {
			username: (userInfo.email == undefined ? '' : userInfo.email).toLowerCase().trim() || '',
			password: userInfo.password || ''
		}

		/* Handle Multiple tap */
		this.isEnabled = false;
		this.isLoading = true;
		this.loginService.login(authObj).subscribe((res: any) => {
			setTimeout(() => {
				this.isLoading = false;
			}, 100)
			this.routerExten.navigate(["/main-dashboard"], { clearHistory: true });
		}, error => {
			if(error.json().type && error.json().type == "NOT VERIFIED") {
				this.isVerified=false;
			}
			this.isLoading = false;
			 this.errorMessage=error.json().msg;
			this.messageService.onError(error);
			setTimeout(() => {
				this.isEnabled = true;
			}, 500);
		})
	}


	ngAfterViewInit() {
		this.secondTextField.nativeElement;

	}

	onReturn(args) {
		let textField = <TextField>args.object;
		this.secondTextField.nativeElement.focus();
	}
	onSecurePassword(secure) {
		this.isSecure = !secure;
	}

	doneTap(args) {
		let objTextField = args.object;
		args.object.android.clearFocus();
		objTextField.dismissSoftInput();
		setTimeout(() => {
			if (args.object.android) {
				objTextField.dismissSoftInput();
				args.object.android.clearFocus();
			}
		}, 100)
	}
}

