"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var router_2 = require("@angular/router");
var authentication_service_1 = require("./../../services/common/authentication.service");
var page_1 = require("ui/page");
var message_service_1 = require("./../../services/common/message.service");
var validation_config_constants_1 = require("./../../config/validation-config.constants");
// var testButton = new buttonModule.Button();
var LoginComponent = (function () {
    function LoginComponent(page, router, routerExten, loginService, messageService) {
        this.page = page;
        this.router = router;
        this.routerExten = routerExten;
        this.loginService = loginService;
        this.messageService = messageService;
        this.loginInfo = {
            email: "",
            password: ""
        };
        this.isSecure = true;
        this.isLoading = false;
        this.isTap = true;
        this.passwordPattern = validation_config_constants_1.ValidationConfig.PASSWORD_PATTERN;
        this.emailpattern = validation_config_constants_1.ValidationConfig.GOOGLE_PATTERN;
        this.isEnabled = true;
        this.isVerified = true;
        this.count = 1;
        this.page.actionBarHidden = true;
    }
    LoginComponent.prototype.ngOnInit = function () {
        this.page.actionBarHidden = true;
        this.userTextField.nativeElement.dismissSoftInput();
        this.secondTextField.nativeElement.dismissSoftInput();
    };
    LoginComponent.prototype.onLogin = function (userInfo) {
        var _this = this;
        this.isEnabled = false;
        this.secondTextField.nativeElement.dismissSoftInput();
        this.errorMessage = '';
        var authObj = {
            username: (userInfo.email == undefined ? '' : userInfo.email).toLowerCase().trim() || '',
            password: userInfo.password || ''
        };
        /* Handle Multiple tap */
        this.isEnabled = false;
        this.isLoading = true;
        this.loginService.login(authObj).subscribe(function (res) {
            setTimeout(function () {
                _this.isLoading = false;
            }, 100);
            _this.routerExten.navigate(["/main-dashboard"], { clearHistory: true });
        }, function (error) {
            if (error.json().type && error.json().type == "NOT VERIFIED") {
                _this.isVerified = false;
            }
            _this.isLoading = false;
            _this.errorMessage = error.json().msg;
            _this.messageService.onError(error);
            setTimeout(function () {
                _this.isEnabled = true;
            }, 500);
        });
    };
    LoginComponent.prototype.ngAfterViewInit = function () {
        this.secondTextField.nativeElement;
    };
    LoginComponent.prototype.onReturn = function (args) {
        var textField = args.object;
        this.secondTextField.nativeElement.focus();
    };
    LoginComponent.prototype.onSecurePassword = function (secure) {
        this.isSecure = !secure;
    };
    LoginComponent.prototype.doneTap = function (args) {
        var objTextField = args.object;
        args.object.android.clearFocus();
        objTextField.dismissSoftInput();
        setTimeout(function () {
            if (args.object.android) {
                objTextField.dismissSoftInput();
                args.object.android.clearFocus();
            }
        }, 100);
    };
    __decorate([
        core_1.ViewChild("firstTextField"),
        __metadata("design:type", core_1.ElementRef)
    ], LoginComponent.prototype, "userTextField", void 0);
    __decorate([
        core_1.ViewChild("secondTextField"),
        __metadata("design:type", core_1.ElementRef)
    ], LoginComponent.prototype, "secondTextField", void 0);
    LoginComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'app-login',
            templateUrl: './login.component.html',
            styleUrls: ['./login.component.css'],
            providers: [message_service_1.MessageService]
        }),
        __metadata("design:paramtypes", [page_1.Page,
            router_2.Router,
            router_1.RouterExtensions,
            authentication_service_1.AuthenticationService,
            message_service_1.MessageService])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibG9naW4uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWlGO0FBQ2pGLHNEQUErRDtBQUMvRCwwQ0FBeUM7QUFDekMseUZBQXVGO0FBRXZGLGdDQUEwQztBQUsxQywyRUFBeUU7QUFRekUsMEZBQThFO0FBRTlFLDhDQUE4QztBQVE5QztJQWdCQyx3QkFBMkIsSUFBVSxFQUM1QixNQUFjLEVBQ2QsV0FBNkIsRUFDN0IsWUFBbUMsRUFDbkMsY0FBOEI7UUFKWixTQUFJLEdBQUosSUFBSSxDQUFNO1FBQzVCLFdBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxnQkFBVyxHQUFYLFdBQVcsQ0FBa0I7UUFDN0IsaUJBQVksR0FBWixZQUFZLENBQXVCO1FBQ25DLG1CQUFjLEdBQWQsY0FBYyxDQUFnQjtRQWhCaEMsY0FBUyxHQUFHO1lBQ2xCLEtBQUssRUFBRSxFQUFFO1lBQ1QsUUFBUSxFQUFFLEVBQUU7U0FDWixDQUFDO1FBQ0ssYUFBUSxHQUFZLElBQUksQ0FBQztRQUN6QixjQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ2xCLFVBQUssR0FBWSxJQUFJLENBQUM7UUFDdEIsb0JBQWUsR0FBQyw4Q0FBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztRQUNsRCxpQkFBWSxHQUFDLDhDQUFnQixDQUFDLGNBQWMsQ0FBQztRQUM3QyxjQUFTLEdBQVksSUFBSSxDQUFDO1FBQzFCLGVBQVUsR0FBUyxJQUFJLENBQUM7UUFnQi9CLFVBQUssR0FBRyxDQUFDLENBQUM7UUFUVCxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7SUFFbEMsQ0FBQztJQUVNLGlDQUFRLEdBQWY7UUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7UUFDakMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNwRCxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQ3ZELENBQUM7SUFFRCxnQ0FBTyxHQUFQLFVBQVEsUUFBYTtRQUFyQixpQkE0QkM7UUEzQkEsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN0RCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUN2QixJQUFJLE9BQU8sR0FBRztZQUNiLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxLQUFLLElBQUksU0FBUyxHQUFHLEVBQUUsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtZQUN4RixRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVEsSUFBSSxFQUFFO1NBQ2pDLENBQUE7UUFFRCx5QkFBeUI7UUFDekIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUMsR0FBUTtZQUNuRCxVQUFVLENBQUM7Z0JBQ1YsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7WUFDeEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFBO1lBQ1AsS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFDeEUsQ0FBQyxFQUFFLFVBQUEsS0FBSztZQUNQLEVBQUUsQ0FBQSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDO2dCQUM3RCxLQUFJLENBQUMsVUFBVSxHQUFDLEtBQUssQ0FBQztZQUN2QixDQUFDO1lBQ0QsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7WUFDdEIsS0FBSSxDQUFDLFlBQVksR0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDO1lBQ3BDLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25DLFVBQVUsQ0FBQztnQkFDVixLQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUN2QixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQTtJQUNILENBQUM7SUFHRCx3Q0FBZSxHQUFmO1FBQ0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUM7SUFFcEMsQ0FBQztJQUVELGlDQUFRLEdBQVIsVUFBUyxJQUFJO1FBQ1osSUFBSSxTQUFTLEdBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN2QyxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUM1QyxDQUFDO0lBQ0QseUNBQWdCLEdBQWhCLFVBQWlCLE1BQU07UUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQU0sQ0FBQztJQUN6QixDQUFDO0lBRUQsZ0NBQU8sR0FBUCxVQUFRLElBQUk7UUFDWCxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2pDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ2hDLFVBQVUsQ0FBQztZQUNWLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDekIsWUFBWSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xDLENBQUM7UUFDRixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUE7SUFDUixDQUFDO0lBcEY0QjtRQUE1QixnQkFBUyxDQUFDLGdCQUFnQixDQUFDO2tDQUFnQixpQkFBVTt5REFBQztJQUN6QjtRQUE3QixnQkFBUyxDQUFDLGlCQUFpQixDQUFDO2tDQUFrQixpQkFBVTsyREFBQztJQUY5QyxjQUFjO1FBUDFCLGdCQUFTLENBQUM7WUFDVixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsUUFBUSxFQUFFLFdBQVc7WUFDckIsV0FBVyxFQUFFLHdCQUF3QjtZQUNyQyxTQUFTLEVBQUUsQ0FBQyx1QkFBdUIsQ0FBQztZQUNwQyxTQUFTLEVBQUUsQ0FBQyxnQ0FBYyxDQUFDO1NBQzNCLENBQUM7eUNBaUJnQyxXQUFJO1lBQ3BCLGVBQU07WUFDRCx5QkFBZ0I7WUFDZiw4Q0FBcUI7WUFDbkIsZ0NBQWM7T0FwQjNCLGNBQWMsQ0FzRjFCO0lBQUQscUJBQUM7Q0FBQSxBQXRGRCxJQXNGQztBQXRGWSx3Q0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBJbmplY3QsIEVsZW1lbnRSZWYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUm91dGVyRXh0ZW5zaW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IEF1dGhlbnRpY2F0aW9uU2VydmljZSB9IGZyb20gJy4vLi4vLi4vc2VydmljZXMvY29tbW9uL2F1dGhlbnRpY2F0aW9uLnNlcnZpY2UnO1xuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCB7IFBhZ2UsIEV2ZW50RGF0YSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5pbXBvcnQgKiBhcyBUb2FzdCBmcm9tIFwibmF0aXZlc2NyaXB0LXRvYXN0XCI7XG5pbXBvcnQgKiBhcyBFbWFpbFZhbGlkYXRvciBmcm9tIFwiZW1haWwtdmFsaWRhdG9yXCI7XG5pbXBvcnQgeyBUZXh0RmllbGQgfSBmcm9tICd1aS90ZXh0LWZpZWxkJztcbmltcG9ydCB7IFNlY3VyZVN0b3JhZ2UgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXNlY3VyZS1zdG9yYWdlXCI7XG5pbXBvcnQgeyBNZXNzYWdlU2VydmljZSB9IGZyb20gJy4vLi4vLi4vc2VydmljZXMvY29tbW9uL21lc3NhZ2Uuc2VydmljZSc7XG5pbXBvcnQgKiBhcyBhcHBsaWNhdGlvbiBmcm9tIFwiYXBwbGljYXRpb25cIjtcbmltcG9ydCB7IEFuZHJvaWRBcHBsaWNhdGlvbiwgQW5kcm9pZEFjdGl2aXR5QmFja1ByZXNzZWRFdmVudERhdGEgfSBmcm9tIFwiYXBwbGljYXRpb25cIjtcbmltcG9ydCB7IGlzQW5kcm9pZCB9IGZyb20gXCJwbGF0Zm9ybVwiO1xuLy8gaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcInVpL2J1dHRvblwiO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gXCJyeGpzL1J4XCJcbi8vIGltcG9ydCBidXR0b25Nb2R1bGUgPSByZXF1aXJlKFwidWkvYnV0dG9uXCIpO1xuaW1wb3J0IHsgbG9naW4gfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL3VpL2RpYWxvZ3MvZGlhbG9ncyc7XG5pbXBvcnQgeyBWYWxpZGF0aW9uQ29uZmlnIH0gZnJvbSAnLi8uLi8uLi9jb25maWcvdmFsaWRhdGlvbi1jb25maWcuY29uc3RhbnRzJztcblxuLy8gdmFyIHRlc3RCdXR0b24gPSBuZXcgYnV0dG9uTW9kdWxlLkJ1dHRvbigpO1xuQENvbXBvbmVudCh7XG5cdG1vZHVsZUlkOiBtb2R1bGUuaWQsXG5cdHNlbGVjdG9yOiAnYXBwLWxvZ2luJyxcblx0dGVtcGxhdGVVcmw6ICcuL2xvZ2luLmNvbXBvbmVudC5odG1sJyxcblx0c3R5bGVVcmxzOiBbJy4vbG9naW4uY29tcG9uZW50LmNzcyddLFxuXHRwcm92aWRlcnM6IFtNZXNzYWdlU2VydmljZV1cbn0pXG5leHBvcnQgY2xhc3MgTG9naW5Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXHRAVmlld0NoaWxkKFwiZmlyc3RUZXh0RmllbGRcIikgdXNlclRleHRGaWVsZDogRWxlbWVudFJlZjtcblx0QFZpZXdDaGlsZChcInNlY29uZFRleHRGaWVsZFwiKSBzZWNvbmRUZXh0RmllbGQ6IEVsZW1lbnRSZWY7XG5cdHB1YmxpYyBlcnJvck1lc3NhZ2U6IGFueTtcblx0cHVibGljIGxvZ2luSW5mbyA9IHtcblx0XHRlbWFpbDogXCJcIixcblx0XHRwYXNzd29yZDogXCJcIlxuXHR9O1xuXHRwdWJsaWMgaXNTZWN1cmU6IGJvb2xlYW4gPSB0cnVlO1xuXHRwdWJsaWMgaXNMb2FkaW5nID0gZmFsc2U7XG5cdHB1YmxpYyBpc1RhcDogYm9vbGVhbiA9IHRydWU7XG5cdHB1YmxpYyBwYXNzd29yZFBhdHRlcm49VmFsaWRhdGlvbkNvbmZpZy5QQVNTV09SRF9QQVRURVJOO1xuXHRwdWJsaWMgZW1haWxwYXR0ZXJuPVZhbGlkYXRpb25Db25maWcuR09PR0xFX1BBVFRFUk47XG5cdHB1YmxpYyBpc0VuYWJsZWQ6IGJvb2xlYW4gPSB0cnVlO1xuXHRwdWJsaWMgaXNWZXJpZmllZDpib29sZWFuPXRydWU7XG5cblx0cHVibGljIGNvbnN0cnVjdG9yKHByaXZhdGUgcGFnZTogUGFnZSxcblx0XHRwcml2YXRlIHJvdXRlcjogUm91dGVyLFxuXHRcdHByaXZhdGUgcm91dGVyRXh0ZW46IFJvdXRlckV4dGVuc2lvbnMsXG5cdFx0cHJpdmF0ZSBsb2dpblNlcnZpY2U6IEF1dGhlbnRpY2F0aW9uU2VydmljZSxcblx0XHRwcml2YXRlIG1lc3NhZ2VTZXJ2aWNlOiBNZXNzYWdlU2VydmljZSkge1xuXHRcdHRoaXMucGFnZS5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xuXG5cdH1cblxuXHRwdWJsaWMgbmdPbkluaXQoKSB7XG5cdFx0dGhpcy5wYWdlLmFjdGlvbkJhckhpZGRlbiA9IHRydWU7XG5cdFx0dGhpcy51c2VyVGV4dEZpZWxkLm5hdGl2ZUVsZW1lbnQuZGlzbWlzc1NvZnRJbnB1dCgpO1xuXHRcdHRoaXMuc2Vjb25kVGV4dEZpZWxkLm5hdGl2ZUVsZW1lbnQuZGlzbWlzc1NvZnRJbnB1dCgpO1xuXHR9XG5cdGNvdW50ID0gMTtcblx0b25Mb2dpbih1c2VySW5mbzogYW55KSB7XG5cdFx0dGhpcy5pc0VuYWJsZWQgPSBmYWxzZTtcblx0XHR0aGlzLnNlY29uZFRleHRGaWVsZC5uYXRpdmVFbGVtZW50LmRpc21pc3NTb2Z0SW5wdXQoKTtcblx0XHR0aGlzLmVycm9yTWVzc2FnZSA9ICcnO1xuXHRcdGxldCBhdXRoT2JqID0ge1xuXHRcdFx0dXNlcm5hbWU6ICh1c2VySW5mby5lbWFpbCA9PSB1bmRlZmluZWQgPyAnJyA6IHVzZXJJbmZvLmVtYWlsKS50b0xvd2VyQ2FzZSgpLnRyaW0oKSB8fCAnJyxcblx0XHRcdHBhc3N3b3JkOiB1c2VySW5mby5wYXNzd29yZCB8fCAnJ1xuXHRcdH1cblxuXHRcdC8qIEhhbmRsZSBNdWx0aXBsZSB0YXAgKi9cblx0XHR0aGlzLmlzRW5hYmxlZCA9IGZhbHNlO1xuXHRcdHRoaXMuaXNMb2FkaW5nID0gdHJ1ZTtcblx0XHR0aGlzLmxvZ2luU2VydmljZS5sb2dpbihhdXRoT2JqKS5zdWJzY3JpYmUoKHJlczogYW55KSA9PiB7XG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0dGhpcy5pc0xvYWRpbmcgPSBmYWxzZTtcblx0XHRcdH0sIDEwMClcblx0XHRcdHRoaXMucm91dGVyRXh0ZW4ubmF2aWdhdGUoW1wiL21haW4tZGFzaGJvYXJkXCJdLCB7IGNsZWFySGlzdG9yeTogdHJ1ZSB9KTtcblx0XHR9LCBlcnJvciA9PiB7XG5cdFx0XHRpZihlcnJvci5qc29uKCkudHlwZSAmJiBlcnJvci5qc29uKCkudHlwZSA9PSBcIk5PVCBWRVJJRklFRFwiKSB7XG5cdFx0XHRcdHRoaXMuaXNWZXJpZmllZD1mYWxzZTtcblx0XHRcdH1cblx0XHRcdHRoaXMuaXNMb2FkaW5nID0gZmFsc2U7XG5cdFx0XHQgdGhpcy5lcnJvck1lc3NhZ2U9ZXJyb3IuanNvbigpLm1zZztcblx0XHRcdHRoaXMubWVzc2FnZVNlcnZpY2Uub25FcnJvcihlcnJvcik7XG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0dGhpcy5pc0VuYWJsZWQgPSB0cnVlO1xuXHRcdFx0fSwgNTAwKTtcblx0XHR9KVxuXHR9XG5cblxuXHRuZ0FmdGVyVmlld0luaXQoKSB7XG5cdFx0dGhpcy5zZWNvbmRUZXh0RmllbGQubmF0aXZlRWxlbWVudDtcblxuXHR9XG5cblx0b25SZXR1cm4oYXJncykge1xuXHRcdGxldCB0ZXh0RmllbGQgPSA8VGV4dEZpZWxkPmFyZ3Mub2JqZWN0O1xuXHRcdHRoaXMuc2Vjb25kVGV4dEZpZWxkLm5hdGl2ZUVsZW1lbnQuZm9jdXMoKTtcblx0fVxuXHRvblNlY3VyZVBhc3N3b3JkKHNlY3VyZSkge1xuXHRcdHRoaXMuaXNTZWN1cmUgPSAhc2VjdXJlO1xuXHR9XG5cblx0ZG9uZVRhcChhcmdzKSB7XG5cdFx0bGV0IG9ialRleHRGaWVsZCA9IGFyZ3Mub2JqZWN0O1xuXHRcdGFyZ3Mub2JqZWN0LmFuZHJvaWQuY2xlYXJGb2N1cygpO1xuXHRcdG9ialRleHRGaWVsZC5kaXNtaXNzU29mdElucHV0KCk7XG5cdFx0c2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRpZiAoYXJncy5vYmplY3QuYW5kcm9pZCkge1xuXHRcdFx0XHRvYmpUZXh0RmllbGQuZGlzbWlzc1NvZnRJbnB1dCgpO1xuXHRcdFx0XHRhcmdzLm9iamVjdC5hbmRyb2lkLmNsZWFyRm9jdXMoKTtcblx0XHRcdH1cblx0XHR9LCAxMDApXG5cdH1cbn1cblxuIl19